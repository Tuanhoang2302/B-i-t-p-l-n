public class Target {
    int yPos = 0;
    int xPos = 0;

    int baseGround;
    int RIGHT = 1;
    int DOWN = 2;
    int LEFT = 3;
    int UP = 4;

    public Target(int xPos, int yPos){
        this.xPos = xPos;
        this.yPos = yPos;

    }
}
