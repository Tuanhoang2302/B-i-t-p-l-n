public class Spawner {
    public int x;
    public int y;

    public Spawner(int x, int y){
        this.x = x;
        this.y = y;
    }
}
