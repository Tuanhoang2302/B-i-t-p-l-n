public class EnemyAutoMove extends EnemyAuto {
    public EnemyAutoMove(int id){
        super(id);
    }

    public void move(EnemyState enemy){
        //System.out.println(enemy.xPos % GameField.SIZE);
        //System.out.println(enemy.yPos);
        if((int)enemy.xPos % GameField.SIZE == 0 && (int)enemy.yPos % GameField.SIZE == 0 && enemy.routePosX == (int)enemy.xPos / GameField.SIZE && enemy.routePosY == (int)enemy.yPos / GameField.SIZE){
            if(enemy.routePosX == baseposX && enemy.routePosY == baseposY){
                enemy.attack = true;
            } else {
                if(route.route[enemy.routePosX][enemy.routePosY] == route.UP){
                    enemy.routePosY--;
                }else if(route.route[enemy.routePosX][enemy.routePosY] == route.DOWN){
                    enemy.routePosY++;
                }else if(route.route[enemy.routePosX][enemy.routePosY] == route.RIGHT){
                    enemy.routePosX ++;
                }else if(route.route[enemy.routePosX][enemy.routePosY] == route.LEFT){
                    enemy.routePosX--;
                }else {
                }
            }
        }else {
            double xPos = (int)enemy.xPos / GameField.SIZE ;
            double yPos = (int)enemy.yPos / GameField.SIZE;

            if(xPos > enemy.routePosX){
                enemy.xPos -= enemy.enemy.speed / 24 * GameField.speed;
                if(xPos < enemy.routePosX * GameField.SIZE){
                    enemy.xPos = enemy.routePosX * GameField.SIZE;
                }
            }
            if(xPos < enemy.routePosX){
                enemy.xPos += enemy.enemy.speed / 24 * GameField.speed;
                if(xPos > enemy.routePosX * GameField.SIZE){
                    enemy.xPos = enemy.routePosX * GameField.SIZE;
                }
            }
            if(yPos > enemy.routePosY){
                enemy.yPos -= enemy.enemy.speed / 24 * GameField.speed;
                if(yPos < enemy.routePosY * GameField.SIZE){
                    enemy.yPos = enemy.routePosY * GameField.SIZE;
                }
            }
            if(yPos < enemy.routePosY){
                enemy.yPos += enemy.enemy.speed / 24 * GameField.speed;
                if(yPos > enemy.routePosY * GameField.SIZE){
                    enemy.yPos = enemy.routePosY * GameField.SIZE;
                }
            }
        }
    }

}
