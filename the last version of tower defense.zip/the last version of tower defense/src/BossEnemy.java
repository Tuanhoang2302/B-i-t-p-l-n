public class BossEnemy extends Enemy {
    public BossEnemy(int id, int priceReward, int health, double speed, double armor, int dam, int point){
        super(id, priceReward, health, speed, armor, dam, point);
    }
}